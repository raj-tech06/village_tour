from django.apps import AppConfig


class MyvillageappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myvillageapp'




class VillageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myvillageapp'

